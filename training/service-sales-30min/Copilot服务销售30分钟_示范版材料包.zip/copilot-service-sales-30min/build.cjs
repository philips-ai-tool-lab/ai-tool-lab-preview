const fs=require('fs');const path=require('path');
let esbuild;try{esbuild=require('esbuild')}catch{esbuild=require('C:/petproject/philips-agent-builder-lab/node_modules/esbuild')}
const root=__dirname;
esbuild.buildSync({entryPoints:[path.join(root,'src/App.jsx')],bundle:true,minify:true,format:'iife',outfile:path.join(root,'build/app.js'),nodePaths:[path.join(root,'node_modules'),'C:/petproject/philips-agent-builder-lab/node_modules'],define:{'process.env.NODE_ENV':'"production"'}});
const assets={};for(const f of fs.readdirSync(path.join(root,'assets'))){const mime=f.endsWith('.png')?'image/png':'image/jpeg';assets[f]='data:'+mime+';base64,'+fs.readFileSync(path.join(root,'assets',f)).toString('base64')}
const js=fs.readFileSync(path.join(root,'build/app.js'),'utf8').replace(/<\/script/gi,'<\\/script');const css=fs.readFileSync(path.join(root,'build/app.css'),'utf8');
fs.writeFileSync(path.join(root,'Copilot服务销售培训.html'),`<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Copilot 服务销售实操 · 30分钟</title><style>${css}</style></head><body><div id="root"></div><script>window.DECK_ASSETS=${JSON.stringify(assets)};</script><script>${js}</script></body></html>`);
console.log('Built offline React deck.');
