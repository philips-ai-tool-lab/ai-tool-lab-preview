import React, {useState,useEffect} from 'react';
import {createRoot} from 'react-dom/client';
import {slides,prompts,promptNames,sources,mainCount} from './deck.mjs';
import './styles.css';

const A=window.DECK_ASSETS||{};
const T=({as:Tag='div',children,className='',style={}})=><Tag data-ppt="text" className={className} style={style}>{children}</Tag>;
function Evidence({name,crop='',phone=false}){return <div className={`evidence ${phone?'phone':''} ${crop}`} data-ppt="image"><img src={A[name]||`assets/${name}`} alt={name}/></div>}
function Steps({rows}){return <div className="steps">{rows.map(([title,body],i)=><div className="step" key={i}><T className="stepNum">{String(i+1).padStart(2,'0')}</T><div><T className="stepTitle">{title}</T><T className="stepBody">{body}</T></div></div>)}</div>}
function Rows({rows}){return <div className="rows">{rows.map(([a,b,c],i)=><div className="row" key={i}><T className="rowA">{a}</T><T className="rowB">{b}</T>{c&&<T className="rowC">{c}</T>}</div>)}</div>}
function Slide({s,index,answer=true,openPrompt=()=>{}}){return <article className={`slide ${s.type} ${s.type==='cover'||s.type==='qa'?'dark':''}`} data-index={index}>
  <header><T className="eyebrow">{s.section}</T><T className="brand">COPILOT  /  SERVICE SALES</T></header>
  <T as="h1">{s.title}</T>{s.subtitle&&<T className="subtitle">{s.subtitle}</T>}
  <main>
  {s.type==='chapter'&&<div className="chapterBody"><T className="chapterNumber">{s.number}</T><div className="chapterCopy"><T className="chapterLead">{s.lead}</T><T className="chapterRoute">{s.route}</T><T className="chapterOutcome">{s.outcome}</T></div></div>}
  {s.type==='resources'&&<div className="learningResources">{s.resources.map((r,i)=><section className="learningResource" key={r.url}><T className="resourceNumber">{String(i+1).padStart(2,'0')}</T><div><T className="resourceGoal">{r.title}</T><T className="resourceName">{r.name}</T></div><div><T className="resourceExplanation">{r.body}</T><a data-ppt="text" href={r.url} target="_blank" rel="noreferrer">{r.url}</a></div></section>)}</div>}
  {(s.type==='lesson'||s.type==='walk')&&<><div className={`teachingLayout ${s.type==='walk'?'withEvidence':''}`}><div className="teachingNarrative">{s.blocks.map(([h,p],i)=><section key={i}><T className="teachingHeading">{String(i+1).padStart(2,'0')}　{h}</T><T className="teachingBody">{p}</T></section>)}</div><div className="teachingExample">{s.image?<><Evidence name={s.image} crop={s.crop||''} phone={s.phone}/><T className="imageCaption">{s.caption}</T></>:<><T className="exampleLabel">{s.exampleTitle}</T>{s.exampleRows?s.exampleRows.map(([h,p],i)=><div className="exampleRow" key={i}><T className="exampleHeading">{h}</T><T className="exampleBody">{p}</T></div>):<T className="exampleText">{s.example}</T>}</>}</div></div><div className="teachingConclusion"><T className="conclusionLabel">{s.conclusionLabel||'这一页的结论'}</T><T>{s.conclusion}</T></div></>}
  {s.type==='matrix'&&<><T className="matrixIntro">{s.intro}</T><div className="capabilityTable"><div className="tableHead">{s.headings.map(h=><T key={h}>{h}</T>)}</div>{s.rows.map((r,i)=><div className="tableLine" key={i}>{r.map((v,j)=><T key={j}>{v}</T>)}</div>)}</div><div className="teachingConclusion"><T className="conclusionLabel">选择方法</T><T>{s.conclusion}</T></div></>}
  {s.type==='cover'&&<><T className="coverBig">30</T><T className="coverMin">MINUTES</T><div className="coverBottom"><T>15分钟功能入门，15分钟案例示范</T><T className="coverSmall">电脑讲解  ·  手机应用  ·  案例示范</T></div><div className="coverImage"><Evidence name="mobile-brief.jpg" phone/></div></>}
  {s.type==='agenda'&&<Rows rows={s.rows}/>}
  {s.type==='columns'&&<div className="columnGrid">{s.columns.map((c,i)=><div className="col" key={i}><T className="colLabel">{c.label}</T><T className="colTitle">{c.title}</T><T className="colBody">{c.body}</T></div>)}</div>}
  {s.type==='desktop'&&<div className="desktopLayout"><Evidence name={s.image} crop={s.crop}/><Steps rows={s.steps}/></div>}
  {s.type==='formula'&&<Rows rows={s.rows}/>}
  {s.type==='prompt'&&<div className="promptLayout"><T className="promptText">{prompts[s.prompt]}</T><div className="aside">{s.aside.map((x,i)=><T key={i} className={i%2?'asideBody':'asideTitle'}>{x}</T>)}</div></div>}
  {(s.type==='mobile'||s.type==='mobileMap')&&<div className="mobileLayout"><div className="phoneArea"><Evidence name={s.image} phone/></div><Steps rows={s.steps}/></div>}
  {(s.type==='flow'||s.type==='takeaway')&&<Rows rows={s.rows}/>}
  {s.type==='twoPhones'&&<div className="twoPhoneLayout">{s.images.map((img,i)=><div className="phonePair" key={img}><Evidence name={img} phone/><div className="phoneExplanation"><T className="colTitle">{s.columns[i].title}</T><T className="colBody">{s.columns[i].body}</T></div></div>)}</div>}
  {s.type==='followup'&&<div className="followLayout"><div><T className="colLabel">拜访记录 / 培训案例</T><T className="quote">{s.quote}</T><T className="asideBody">任务：整理事项、负责人和时间，再起草客户邮件。</T></div><div className="letter"><T className="colLabel">邮件草稿 / 示例</T><T className="letterText">{s.result}</T><T className="letterEnd">下一步：发送主题介绍，安排需求交流</T></div></div>}
  
  {s.type==='review'&&<div className="reviewRows">{s.rows.map(([q,a],i)=><div className="reviewRow" key={i}><T className="reviewQ">{q}</T><T className={`reviewA ${!answer?'conceal':''}`}>{answer?a:'先判断，再说出依据'}</T></div>)}</div>}
  {s.type==='qa'&&<Rows rows={s.rows}/>}
  {s.type==='promptIndex'&&<div className="promptIndexGrid">{Object.keys(prompts).map((p,i)=><button onClick={()=>openPrompt(p)} key={p}><T className="indexNumber">{String(i+1).padStart(2,'0')}</T><T>{promptNames[p]}</T></button>)}</div>}
  {s.type==='sources'&&<div className="sourceContent"><div>{Object.entries(sources).map(([k,url],i)=><div className="source" key={k}><T className="sourceTitle">{['AI Skills Navigator 基础学习','Microsoft Learn 岗位课程 MS-4004','AI Tool Lab 分步实操','Copilot Chat 功能课程','Microsoft 365 应用学习路径'][i]}</T><a href={url} target="_blank" rel="noreferrer" data-ppt="text">{url}</a></div>)}</div><div className="sourceAside"><T className="colTitle">用户提供的素材</T><T className="colBody">4张电脑端案例截图、4张手机端截图。既有33页第一课、90分钟课程及Lab资料，提供电脑操作、学习入口和提示词方法。</T><T className="sourceNote">课堂案例：电脑端准备客户拜访，手机端复习，拜访后整理行动与邮件。</T></div></div>}
  </main>
  {s.foot&&<T className="footnote">{s.foot}</T>}
  <footer><T>{s.time?`建议 ${s.time} 分钟`:'课后参考'}</T><T>{String(index+1).padStart(2,'0')} / {slides.length}</T></footer>
 </article>}

function App(){
 const initial=Math.min(slides.length-1,Math.max(0,(parseInt(location.hash.slice(1))||1)-1));
 const [idx,setIdx]=useState(initial),[overview,setOverview]=useState(false),[notes,setNotes]=useState(false),[prompt,setPrompt]=useState(null),[copied,setCopied]=useState(false),[answer,setAnswer]=useState(false),[scale,setScale]=useState(1);
 const all=new URLSearchParams(location.search).has('print');
 const s=slides[idx];
 const go=(n)=>{setIdx(Math.max(0,Math.min(slides.length-1,n)));setAnswer(false);setOverview(false)};
 useEffect(()=>{const resize=()=>setScale(Math.min((innerWidth-40)/1600,(innerHeight-130)/900));resize();addEventListener('resize',resize);return()=>removeEventListener('resize',resize)},[]);
 useEffect(()=>{location.hash=String(idx+1)},[idx]);
 useEffect(()=>{const f=(e)=>{if(prompt||['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName))return;if(['ArrowRight','PageDown',' '].includes(e.key)){e.preventDefault();go(idx+1)}if(['ArrowLeft','PageUp'].includes(e.key)){e.preventDefault();go(idx-1)}if(e.key==='Home')go(0);if(e.key==='End')go(slides.length-1);if(e.key==='n')setNotes(n=>!n);if(e.key==='Escape'){setOverview(false);setNotes(false)}};addEventListener('keydown',f);return()=>removeEventListener('keydown',f)},[idx,prompt]);
 const openPrompt=p=>{setCopied(false);setPrompt(p)};
 const copy=async()=>{try{await navigator.clipboard.writeText(prompts[prompt]);setCopied(true)}catch{const el=document.querySelector('textarea');el.focus();el.select();setCopied(false)}};
 if(all)return <div className="printDeck">{slides.map((s,i)=><Slide key={i} s={s} index={i} openPrompt={openPrompt}/>)}</div>;
 return <><div className="appTop"><span>服务销售 Copilot 培训</span><span>30分钟课程 · {idx<mainCount?`主课 ${idx+1}/${mainCount}`:'课后参考'}</span></div><div className="stage" style={{width:1600*scale,height:900*scale}}><div style={{transform:`scale(${scale})`,transformOrigin:'top left'}}><Slide s={s} index={idx} answer={answer} openPrompt={openPrompt}/></div></div>
 <nav className="toolbar"><button onClick={()=>setOverview(true)}>目录</button><button onClick={()=>go(idx-1)} disabled={!idx}>上一页</button><span>{idx+1} / {slides.length}</span><button onClick={()=>go(idx+1)} disabled={idx===slides.length-1}>下一页</button><i/><button onClick={()=>setNotes(!notes)}>讲师备注</button>{s.prompt&&<button className="primary" onClick={()=>openPrompt(s.prompt)}>复制提示词</button>}{s.type==='review'&&<button className="primary" onClick={()=>setAnswer(!answer)}>{answer?'隐藏答案':'展示答案'}</button>}<button onClick={()=>document.fullscreenElement?document.exitFullscreen():document.documentElement.requestFullscreen()}>全屏</button><button onClick={()=>{window.open(location.href.split('?')[0].split('#')[0]+'?print=1','_blank')}}>打印版</button></nav>
 {notes&&<aside className="notes"><button onClick={()=>setNotes(false)}>关闭</button><h2>{s.title.replace('\n',' ')}</h2><p>{s.notes}</p>{s.prompt&&<p>{prompts[s.prompt]}</p>}<small>下一页：{slides[idx+1]?.title||'结束'} · N 键开关备注</small></aside>}
 {overview&&<div className="overlay"><div className="overview"><div className="modalHeader"><h2>课程目录</h2><button onClick={()=>setOverview(false)}>关闭</button></div><div className="overviewGrid">{slides.map((s,i)=><button key={i} onClick={()=>go(i)} className={i===idx?'active':''}><b>{String(i+1).padStart(2,'0')}</b><span>{s.title.replace('\n',' ')}</span><small>{s.time?s.time+' 分钟':'参考'}</small></button>)}</div></div></div>}
 {prompt&&<div className="overlay"><div className="promptModal"><div className="modalHeader"><h2>{promptNames[prompt]}</h2><button onClick={()=>setPrompt(null)}>关闭</button></div><textarea readOnly value={prompts[prompt]}/><button className="primary" onClick={copy}>{copied?'已复制':'复制完整提示词'}</button><small>若浏览器限制剪贴板，可选中文本手动复制。</small></div></div>}
 </>;
}
window.DECK_DATA={slides,prompts,promptNames,sources,mainCount};
createRoot(document.getElementById('root')).render(<App/>);

